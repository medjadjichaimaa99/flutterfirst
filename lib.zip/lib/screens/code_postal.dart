import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutterfirst/screens/nb_personne.dart';

class Code_postal extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      backgroundColor: Colors.white,
      body: new Container(
          padding: const EdgeInsets.all(40.0),
          child: new Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          new Text("Votre Code Postal",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16),),
          new SizedBox(height: 20,),
          new Text("La palce dans laquelle vous etes actuellement ? ",style: TextStyle(color: Colors.black.withOpacity(0.6),fontStyle: FontStyle.italic),),
          new SizedBox(height: 20,),
          new SizedBox(height: 20,),
          new SizedBox(height: 20,),
          new TextField(
            style: TextStyle(color: Colors.black.withOpacity(0.8),fontStyle: FontStyle.italic),
            decoration: new InputDecoration(labelText: "saisir"),
            keyboardType: TextInputType.number,
            inputFormatters: <TextInputFormatter>[
            WhitelistingTextInputFormatter.digitsOnly
           ]  , // Only numbers can be entered
          ),
           new SizedBox(height: 20,),
          new SizedBox(height: 20,),
          new SizedBox(height: 20,),
          new MaterialButton( 
                      height: 60.0, 
                      minWidth: 350.0, 
                      color: Color(0xFFDD208A), 
                      textColor: Colors.white, 
                      child: new Text("Suivant "), 
                      onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>Nombre_personne()),);},
                      splashColor: Colors.redAccent,
                      shape: RoundedRectangleBorder(side: BorderSide(
                      color: Color(0xFFDD208A),
                      width: 1,
                      style: BorderStyle.solid
                      ), borderRadius: BorderRadius.circular(20)),
                 ),
        ],
      )),
    );
     }
}
     /*return new Scaffold(
      backgroundColor: Colors.white,
      body: new Container(
          padding: const EdgeInsets.all(40.0),
          child: new Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          new Text("Votre Code Postal",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16),),
          new SizedBox(height: 20,),
          new Text("La palce dans laquelle vous etes actuellement ?",style: TextStyle(color: Colors.black.withOpacity(0.6),fontStyle: FontStyle.italic),),
          new SizedBox(height: 20,),
          new SizedBox(height: 20,),
          new SizedBox(height: 20,),
          new TextField(
            style: TextStyle(color: Colors.black.withOpacity(0.8),fontStyle: FontStyle.italic),
            decoration: new InputDecoration(labelText: "saisir"),
            keyboardType: TextInputType.number,
            inputFormatters: <TextInputFormatter>[
            WhitelistingTextInputFormatter.digitsOnly
           ]  , // Only numbers can be entered
          ),
           new SizedBox(height: 20,),
          new SizedBox(height: 20,),
          new SizedBox(height: 20,),
          new MaterialButton( 
                      height: 60.0, 
                      minWidth: 350.0, 
                      color: Color(0xFFDD208A), 
                      textColor: Colors.white, 
                      child: new Text("Suivant "), 
                      onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>Nombre_personne()),);},
                      splashColor: Colors.redAccent,
                      shape: RoundedRectangleBorder(side: BorderSide(
                      color: Color(0xFFDD208A),
                      width: 1,
                      style: BorderStyle.solid
                      ), borderRadius: BorderRadius.circular(20)),
                 ),
        ],
      )),
    );*/