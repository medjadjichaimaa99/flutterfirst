import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutterfirst/screens/m%C3%A9nage.dart';

import 'code_postal.dart';

class Nombre_personne extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
     return new Scaffold(
      backgroundColor: Colors.white,
      body: new Container(
          padding: const EdgeInsets.all(40.0),
          child: new Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          new Text("Nombre de personnes avec vous",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16),),
          new SizedBox(height: 20,),
          new Text("Vous etes inclus, S'il vous plait faites en sorte qu'une seule personne qui remplie ce formulaire chaque jour ",style: TextStyle(color: Colors.black.withOpacity(0.6),fontStyle: FontStyle.italic),),
          new SizedBox(height: 20,),
          new SizedBox(height: 20,),
          new SizedBox(height: 20,),
          new TextField(
            style: TextStyle(color: Colors.black.withOpacity(0.8),fontStyle: FontStyle.italic),
            decoration: new InputDecoration(labelText: "saisir"),
            keyboardType: TextInputType.number,
            inputFormatters: <TextInputFormatter>[
            WhitelistingTextInputFormatter.digitsOnly
           ]  , // Only numbers can be entered
          ),
           new SizedBox(height: 20,),
          new SizedBox(height: 20,),
          new SizedBox(height: 20,),
          new MaterialButton( 
                      height: 60.0, 
                      minWidth: 350.0, 
                      color: Color(0xFFDD208A), 
                      textColor: Colors.white, 
                      child: new Text("Suivant "), 
                      onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>Menage()),);},
                      splashColor: Colors.redAccent,
                      shape: RoundedRectangleBorder(side: BorderSide(
                      color: Color(0xFFDD208A),
                      width: 1,
                      style: BorderStyle.solid
                      ), borderRadius: BorderRadius.circular(20)),
                 ),
        ],
      )),
    );
  }
}