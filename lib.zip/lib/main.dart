import 'dart:ui' as prefix0;
import 'package:flutter/material.dart';
import 'package:flutterfirst/screens/code_postal.dart';
import 'package:flutterfirst/screens/home_material.dart';
void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Covid',
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.white,
      ),
      home: HomeScreen(),
    );
        }
      }
class HomeScreen extends StatefulWidget{
  
  HomeScreenPage createState()=> HomeScreenPage();
}
final List<String> wilaya = ["Adrar","Chlef","Oran","Alger"] ;
String selectedItem = wilaya[0];
class HomeScreenPage extends  State<HomeScreen> {
  get logIn => null;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(children: <Widget>[
      ClipPath(
        clipper: MyClipper(),
                child: Container(
                 height: 360,
                 width: double.infinity,
                 decoration: BoxDecoration(gradient: LinearGradient(
                   begin: Alignment.topRight,
                   end: Alignment.bottomLeft,
                   colors: [
                   Color(0xFFFFFFFF),
                   Color(0xFFFFFFFF),
                 ]),
                 image: DecorationImage(image: AssetImage("assets/images/1.jpg"))
                 ),
                 child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                   children: <Widget>[
                     Align(alignment: Alignment.bottomRight,),
                     SizedBox(height: 20,),
                 ],),
                ),
              ),
               Container(
                margin: EdgeInsets.symmetric(horizontal: 10),
                padding: EdgeInsets.symmetric(vertical: 10,horizontal: 10),
               
                 child: 
                  Text("veuillez sélectionner votre Wilaya\n",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 16),),
 
               ),
              Container(
                margin: EdgeInsets.symmetric(horizontal: 20),
                padding: EdgeInsets.symmetric(vertical: 10,horizontal: 20),
                height: 60,
                width: 200,
                decoration: BoxDecoration(color: Colors.white,
                borderRadius: BorderRadius.circular(25),
                border: Border.all(color: Color(0xFF3383CD),)),
                child: Row(children: <Widget>[
                    Icon(Icons.room,color: Color(0xFF3383CD),),
                    Expanded(
                      child:  DropdownButton<String>(
                       value: selectedItem, 
                       isExpanded: true,
                       underline: SizedBox(),   
                      onChanged: (value){
                      setState(() {
                         selectedItem=value;
                      });
                    },
                    items: wilaya.map<DropdownMenuItem<String>>((value){
                            return DropdownMenuItem(child: Text(value),
                            value: value,
                            );
                          }).toList(),
                     ),),
                  ],),
              ),
              SizedBox(height: 20),
              Padding(padding: EdgeInsets.symmetric(horizontal: 20),
              child: Column(children: <Widget>[
               new Container(
                     child: new MaterialButton( 
                      height: 60.0, 
                      minWidth: 350.0, 
                      color: Color(0xFFDD208A), 
                      textColor: Colors.white, 
                      child: new Text("Suivant "), 
                      onPressed: (){ Navigator.push(context, MaterialPageRoute(builder: (context)=>Code_postal()),);},
                      splashColor: Colors.redAccent,
                      shape: RoundedRectangleBorder(side: BorderSide(
                      color: Color(0xFFDD208A),
                      width: 1,
                      style: BorderStyle.solid
                      ), borderRadius: BorderRadius.circular(20)),
                 ),
                    margin: new EdgeInsets.only(top: 20.0),
                ),
              ],),
            )
              ],
              ),
              appBar: AppBar(backgroundColor:Color(0xFFFFFFFF) ,
              iconTheme: new IconThemeData(color: Colors.black),
                title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  padding: const EdgeInsets.all(8.0), ),
                  Image.asset(
                 'assets/images/Logo.png',
                  fit: BoxFit.contain,
                  height: 50,
                  ),
              
            ],
            ),),
              drawer: SideMenu(), backgroundColor: Colors.white,
            );
          }
        }
        class MyClipper extends CustomClipper<Path>{
  @override
  prefix0.Path getClip(prefix0.Size size) {
    var path = Path();
    path.lineTo(0, size.height - 80);
    path.quadraticBezierTo(size.width/2, size.height, size.width, size.height - 80);
    path.lineTo(size.width, 0);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<prefix0.Path> oldClipper) {
    return null;
  }
}

